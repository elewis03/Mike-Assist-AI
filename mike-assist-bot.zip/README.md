# Mike-Assist Bot

**Smart task and scheduling assistant for the COO of a cybersecurity software company.**

## 🚀 Purpose
Mike-Assist is a highly structured, bot-only task manager designed to help high-output executives organize, track, and optimize their weekly and daily operations with AI-assisted workflows.

## 📁 Folder Structure
...
