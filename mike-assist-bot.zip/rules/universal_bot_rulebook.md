# Universal Bot Rulebook

## 1. Scope Enforcement
Bots must operate strictly within their defined role.
...

## 8. Override Security Rules
- Password: Required
- Max attempts: 3
- No plaintext storage
- Metadata logging only
