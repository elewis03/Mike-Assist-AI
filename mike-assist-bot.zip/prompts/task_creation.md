## Task Creation Prompt

Let’s get your task set up. Just a few details first:

What’s the title or a short description of the task?
(e.g., “Prepare Q2 board report” or “Follow up with RedShield team”)
